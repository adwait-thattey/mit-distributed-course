package raft

import (
	"sync"
)

const minCapacity = 16

type Queue struct {
	sync.Mutex
	cond   *sync.Cond
	buf    []interface{}
	head   int
	tail   int
	count  int
	minCap int
}

func (q *Queue) resize() {
	newBuf := make([]interface{}, q.count<<1)
	if q.tail > q.head {
		copy(newBuf, q.buf[q.head:q.tail])
	} else {
		n := copy(newBuf, q.buf[q.head:])
		copy(newBuf[n:], q.buf[:q.tail])
	}
	q.head = 0
	q.tail = q.count
	q.buf = newBuf
}

func (q *Queue) growIfFull() {
	if len(q.buf) == 0 {
		if q.minCap == 0 {
			q.minCap = minCapacity
		}
		q.buf = make([]interface{}, q.minCap)
		return
	}
	if q.count == len(q.buf) {
		q.resize()
	}
}

func (q *Queue) shrinkIfExcess() {
	if len(q.buf) > q.minCap && (q.count<<2) == len(q.buf) {
		q.resize()
	}
}

func (q *Queue) next(i int) int {
	return (i + 1) & (len(q.buf) - 1)
}

func (q *Queue) Push(elem interface{}) {
	q.Lock()
	q.growIfFull()
	q.buf[q.tail] = elem
	q.tail = q.next(q.tail)
	q.count++
	q.cond.Signal()
	q.Unlock()
}

func (q *Queue) Pop() interface{} {
	q.Lock()
	if q.count <= 0 {
		q.cond.Wait()
	}
	ret := q.buf[q.head]
	q.buf[q.head] = nil
	q.head = q.next(q.head)
	q.count--
	q.shrinkIfExcess()
	q.Unlock()
	return ret
}

func (q *Queue) Clear() {
	q.Lock()
	modBits := len(q.buf) - 1
	for h := q.head; h != q.tail; h = (h + 1) & modBits {
		q.buf[h] = nil
	}
	q.head = 0
	q.tail = 0
	q.count = 0
	q.Unlock()
}

func MakeQueue() *Queue {
	q := &Queue{}
	q.cond = sync.NewCond(q)
	return q
}
