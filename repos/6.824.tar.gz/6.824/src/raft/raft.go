package raft

//
// this is an outline of the API that raft must expose to
// the service (or tester). see comments below for
// each of these functions for more details.
//
// rf = Make(...)
//   create a new Raft server.
// rf.Start(command interface{}) (index, term, isleader)
//   start agreement on a new log entry
// rf.GetState() (term, isLeader)
//   ask a Raft for its current term, and whether it thinks it is leader
// ApplyMsg
//   each time a new entry is committed to the log, each Raft peer
//   should send an ApplyMsg to the service (or tester)
//   in the same server.
//

import (
	"../labgob"
	"../labrpc"
	"bytes"
	sync "github.com/sasha-s/go-deadlock"
	"log"
	"math/rand"
	//"sync"
	"sync/atomic"
	"time"
)

//
// as each Raft peer becomes aware that successive log entries are
// committed, the peer should send an ApplyMsg to the service (or
// tester) on the same server, via the applyCh passed to Make(). set
// CommandValid to true to indicate that the ApplyMsg contains a newly
// committed log entry.
//
// in Lab 3 you'll want to send other kinds of messages (e.g.,
// snapshots) on the applyCh; at that point you can add fields to
// ApplyMsg, but set CommandValid to false for these other uses.
//
type ApplyMsg struct {
	CommandValid bool
	Command      interface{}
	CommandIndex int
}

type PeerState int

const (
	LEADER PeerState = iota + 1
	CANDIDATE
	FOLLOWER
)

const (
	BASE_ELECTION_TIMEOUT = 300 * time.Millisecond
	RAND_ELECTION_TIMEOUT = 75 * time.Millisecond
	HEARTBEAT_TIMEOUT     = 100 * time.Millisecond
)

type LogEntry struct {
	Command interface{}
	Term    int
}

//
// A Go object implementing a single Raft peer.
//
type Raft struct {
	mu        sync.Mutex          // Lock to protect shared access to this peer's state
	peers     []*labrpc.ClientEnd // RPC end points of all peers
	persister *Persister          // Object to hold this peer's persisted state
	me        int                 // this peer's index into peers[]
	dead      int32               // set by Kill()
	applyChan chan ApplyMsg

	// Your data here (2A, 2B, 2C).
	// Look at the paper's Figure 2 for a description of what
	// state a Raft server must maintain.
	//persistent states
	currentTerm int
	votedFor    int
	log         []LogEntry //indexed from 1

	//volatile states
	commitIndex int
	lastApplied int
	state       PeerState

	//volatile states on leaders
	nextIndex  []int
	matchIndex []int

	cmdQueues []*Queue

	followerStartTime  time.Time
	candidateStartTime time.Time
	leaderStartTime    time.Time
}

// return currentTerm and whether this server
// believes it is the leader.
func (rf *Raft) GetState() (int, bool) {
	rf.mu.Lock()
	defer rf.mu.Unlock()
	if rf.killed() {
		return rf.currentTerm, false
	}
	return rf.currentTerm, rf.state == LEADER
}

//
// save Raft's persistent state to stable storage,
// where it can later be retrieved after a crash and restart.
// see paper's Figure 2 for a description of what should be persistent.
//
func (rf *Raft) persist() {
	w := new(bytes.Buffer)
	e := labgob.NewEncoder(w)
	e.Encode(rf.currentTerm)
	e.Encode(rf.votedFor)
	data := w.Bytes()
	rf.persister.SaveRaftState(data)
}

//
// restore previously persisted state.
//
func (rf *Raft) readPersist(data []byte) {
	if data == nil || len(data) < 1 { // bootstrap without any state?
		return
	}
	r := bytes.NewBuffer(data)
	d := labgob.NewDecoder(r)
	var term, votedFor int
	if err := d.Decode(&term); err != nil {
		log.Fatalf("persist decode error: %v", err)
	}
	if err := d.Decode(&votedFor); err != nil {
		log.Fatalf("persist decode error: %v", err)
	}
	rf.mu.Lock()
	defer rf.mu.Unlock()
	rf.currentTerm = term
	rf.votedFor = votedFor
}

//
// example RequestVote RPC arguments structure.
// field names must start with capital letters!
//
type RequestVoteArgs struct {
	Term         int
	CandidateId  int
	LastLogIndex int
	LastLogTerm  int
}

//
// example RequestVote RPC reply structure.
// field names must start with capital letters!
//
type RequestVoteReply struct {
	Term        int
	VoteGranted bool
}

func (rf *Raft) toFollower() {
	log.Printf("%d[%d]: -> follower", rf.me, rf.currentTerm)
	rf.state = FOLLOWER
	rf.followerStartTime = time.Now()
	rf.votedFor = -1
	rf.persist()
	for _, q := range rf.cmdQueues {
		q.Clear()
	}
	go rf.followerFunc(rf.followerStartTime)
}

//
// example RequestVote RPC handler.
//
func (rf *Raft) RequestVote(args *RequestVoteArgs, reply *RequestVoteReply) {
	rf.mu.Lock()
	defer rf.mu.Unlock()
	reply.Term = rf.currentTerm
	reply.VoteGranted = false
	if args.Term < rf.currentTerm {
		return
	}
	if args.Term > rf.currentTerm {
		rf.currentTerm = args.Term
		reply.Term = args.Term
		if rf.state != FOLLOWER {
			rf.toFollower()
		}
	}
	lastIndex := len(rf.log) - 1
	if (rf.votedFor == -1 || rf.votedFor == args.CandidateId) &&
		(lastIndex < 1 || rf.log[lastIndex].Term < args.LastLogTerm ||
			(rf.log[lastIndex].Term == args.LastLogTerm && lastIndex <= args.LastLogIndex)) {
		if rf.state != FOLLOWER && (rf.state != CANDIDATE || args.CandidateId != rf.me) {
			log.Println("state assert error")
		}
		*reply = RequestVoteReply{
			Term:        args.Term,
			VoteGranted: true,
		}
		rf.currentTerm = args.Term
		rf.votedFor = args.CandidateId
		rf.persist()
		if args.CandidateId != rf.me {
			rf.toFollower()
			rf.votedFor = args.CandidateId
		}
		return
	}
	*reply = RequestVoteReply{
		Term:        args.Term,
		VoteGranted: false,
	}
	return
}

type AppendEntriesArgs struct {
	Term         int
	LeaderId     int
	PrevLogIndex int
	PrevLogTerm  int
	Entries      []LogEntry
	LeaderCommit int
}

type AppendEntriesReply struct {
	Term    int
	Success bool
}

func (rf *Raft) AppendEntries(args *AppendEntriesArgs, reply *AppendEntriesReply) {
	rf.mu.Lock()
	defer rf.mu.Unlock()
	reply.Success = false
	if args.Term < rf.currentTerm {
		reply.Term = rf.currentTerm
		return
	}
	rf.currentTerm = args.Term
	reply.Term = args.Term
	rf.toFollower()
	if args.PrevLogIndex > 0 &&
		(len(rf.log) <= args.PrevLogIndex ||
			rf.log[args.PrevLogIndex].Term != args.PrevLogTerm) {
		log.Printf("%d[%d] follower: args: %v", rf.me, rf.currentTerm, args)
		log.Printf("%d[%d] follower: logs: %v", rf.me, rf.currentTerm, rf.log)
		log.Printf("%d[%d] follower: log check failed", rf.me, rf.currentTerm)
		return
	}

	//log.Printf("%d[%d] follower: args: %v, logs: %v", rf.me, rf.currentTerm, args, rf.log)
	i := args.PrevLogIndex + 1
	j := 0
	//override exist entries
	for ; i < len(rf.log) && j < len(args.Entries); i++ {
		rf.log[i] = args.Entries[j]
		j++
	}
	if j < len(args.Entries) {
		rf.log = append(rf.log, args.Entries[j:]...)
	} else {
		rf.log = rf.log[:i]
	}
	log.Printf("%d[%d] follower: rf.log length %d", rf.me, rf.currentTerm, len(rf.log))
	//if len(args.Entries) > 0 {
	//log.Printf("%d[%d] follower: after merge: %v", rf.me, rf.currentTerm, rf.log)
	//}
	//log.Printf("%d[%d] follower: commitIndex: %d", rf.me, rf.currentTerm, rf.commitIndex)
	if args.LeaderCommit > rf.commitIndex {
		if args.LeaderCommit > len(rf.log)-1 {
			rf.commitIndex = len(rf.log) - 1
		} else {
			rf.commitIndex = args.LeaderCommit
		}
		if rf.commitIndex > rf.lastApplied {
			for i := rf.lastApplied + 1; i <= rf.commitIndex; i++ {
				rf.applyChan <- ApplyMsg{
					CommandValid: true,
					CommandIndex: i,
					Command:      rf.log[i].Command,
				}
				log.Printf("%d[%d] follower: apply command %d", rf.me, rf.currentTerm, i)
			}
			rf.lastApplied = rf.commitIndex
		}
	}
	reply.Success = true
	return
}

//
// example code to send a RequestVote RPC to a server.
// server is the index of the target server in rf.peers[].
// expects RPC arguments in args.
// fills in *reply with RPC reply, so caller should
// pass &reply.
// the types of the args and reply passed to Call() must be
// the same as the types of the arguments declared in the
// handler function (including whether they are pointers).
//
// The labrpc package simulates a lossy network, in which servers
// may be unreachable, and in which requests and replies may be lost.
// Call() sends a request and waits for a reply. If a reply arrives
// within a timeout interval, Call() returns true; otherwise
// Call() returns false. Thus Call() may not return for a while.
// A false return can be caused by a dead server, a live server that
// can't be reached, a lost request, or a lost reply.
//
// Call() is guaranteed to return (perhaps after a delay) *except* if the
// handler function on the server side does not return.  Thus there
// is no need to implement your own timeouts around Call().
//
// look at the comments in ../labrpc/labrpc.go for more details.
//
// if you're having trouble getting RPC to work, check that you've
// capitalized all field names in structs passed over RPC, and
// that the caller passes the address of the reply struct with &, not
// the struct itself.
//
func (rf *Raft) sendRequestVote(server int, args *RequestVoteArgs, reply *RequestVoteReply) bool {
	ok := rf.peers[server].Call("Raft.RequestVote", args, reply)
	return ok
}

func (rf *Raft) sendAppendEntries(server int, args *AppendEntriesArgs, reply *AppendEntriesReply) bool {
	ok := rf.peers[server].Call("Raft.AppendEntries", args, reply)
	return ok
}

//
// the service using Raft (e.g. a k/v server) wants to start
// agreement on the next command to be appended to Raft's log. if this
// server isn't the leader, returns false. otherwise start the
// agreement and return immediately. there is no guarantee that this
// command will ever be committed to the Raft log, since the leader
// may fail or lose an election. even if the Raft instance has been killed,
// this function should return gracefully.
//
// the first return value is the index that the command will appear at
// if it's ever committed. the second return value is the current
// term. the third return value is true if this server believes it is
// the leader.
//
func (rf *Raft) Start(command interface{}) (int, int, bool) {
	rf.mu.Lock()
	if rf.killed() || rf.state != LEADER {
		rf.mu.Unlock()
		return -1, -1, false
	}
	rf.log = append(rf.log, LogEntry{
		Term:    rf.currentTerm,
		Command: command,
	})
	index := len(rf.log) - 1
	currentTerm := rf.currentTerm
	rf.nextIndex[rf.me]++
	rf.matchIndex[rf.me]++
	matchIndex := rf.matchIndex[rf.me]
	log.Printf("%d[%d] leader: start agreement %d", rf.me, rf.currentTerm, len(rf.log)-1)
	rf.mu.Unlock()
	for i, q := range rf.cmdQueues {
		if i != rf.me {
			q.Push(AppendEntriesCommand{
				heartbeat: false,
				submit:    matchIndex,
			})
		}
	}
	return index, currentTerm, true
}

//
// the tester doesn't halt goroutines created by Raft after each test,
// but it does call the Kill() method. your code can use killed() to
// check whether Kill() has been called. the use of atomic avoids the
// need for a lock.
//
// the issue is that long-running goroutines use memory and may chew
// up CPU time, perhaps causing later tests to fail and generating
// confusing debug output. any goroutine with a long-running loop
// should call killed() to check whether it should stop.
//
func (rf *Raft) Kill() {
	atomic.StoreInt32(&rf.dead, 1)
	// Your code here, if desired.
	for i, q := range rf.cmdQueues {
		if i != rf.me {
			q.Push(AppendEntriesCommand{
				exit: true,
			})
		}
	}
	log.Printf("%d killed", rf.me)
}

func (rf *Raft) killed() bool {
	z := atomic.LoadInt32(&rf.dead)
	return z == 1
}

func electionTimeout() time.Duration {
	r := rand.Float64()
	r = r*2 - 1
	r = float64(RAND_ELECTION_TIMEOUT.Milliseconds()) * r
	t := int64(r) + BASE_ELECTION_TIMEOUT.Milliseconds()
	return time.Duration(t) * time.Millisecond
}

func (rf *Raft) toLeader() {
	log.Printf("%d[%d]: -> leader", rf.me, rf.currentTerm)
	rf.state = LEADER
	rf.leaderStartTime = time.Now()
	for i := range rf.nextIndex {
		rf.nextIndex[i] = len(rf.log)
	}
	for i := range rf.matchIndex {
		rf.matchIndex[i] = 0
	}
	rf.matchIndex[rf.me] = len(rf.log) - 1
	go rf.leaderFunc(rf.leaderStartTime)
}

func (rf *Raft) generateAppendEntriesArgs(i int, isHeartbeat bool) AppendEntriesArgs {
	var prevLogIndex, prevLogTerm int
	var entries []LogEntry
	lastLogIndex := len(rf.log) - 1
	if lastLogIndex < rf.nextIndex[i] {
		// hearbeat don't append entries
		if isHeartbeat {
			prevLogIndex = lastLogIndex
		} else {
			prevLogIndex = lastLogIndex - 1
		}
	} else {
		prevLogIndex = rf.nextIndex[i] - 1
	}
	if prevLogIndex < 0 {
		prevLogIndex = 0
	}
	if prevLogIndex > 0 {
		prevLogTerm = rf.log[prevLogIndex].Term
	}
	entries = []LogEntry{}
	if !isHeartbeat {
		if prevLogIndex > 0 {
			entries = rf.log[prevLogIndex+1:]
		} else if len(rf.log) > 1 {
			entries = rf.log[1:]
		}
	}
	args := AppendEntriesArgs{
		Term:         rf.currentTerm,
		LeaderId:     rf.me,
		PrevLogIndex: prevLogIndex,
		PrevLogTerm:  prevLogTerm,
		Entries:      entries,
		LeaderCommit: rf.commitIndex,
	}
	return args
}

type AppendEntriesCommand struct {
	heartbeat bool
	submit    int
	exit      bool
}

func (rf *Raft) appendEntriesFunc(index int, cmdQueue *Queue) {
	changed := func() bool {
		rf.mu.Lock()
		if rf.state != LEADER {
			rf.mu.Unlock()
			return true
		}
		return false
	}
	for {
		cmd := (cmdQueue.Pop()).(AppendEntriesCommand)
		isHeartbeat := cmd.heartbeat
		submitIndex := cmd.submit
		if cmd.exit {
			return
		}
		if changed() {
			continue
		}
		if !isHeartbeat && submitIndex <= rf.matchIndex[index] {
			rf.mu.Unlock()
			continue
		}
		args := rf.generateAppendEntriesArgs(index, isHeartbeat)
		rf.mu.Unlock()
		reply := AppendEntriesReply{}
		if isHeartbeat {
			log.Printf("%d[%d] leader: send heartbeat to %d", rf.me, rf.currentTerm, index)
		} else {
			log.Printf("%d[%d] leader: send appendEntries for %d to %d", rf.me, rf.currentTerm, submitIndex, index)
		}
		if ok := rf.sendAppendEntries(index, &args, &reply); !ok {
			log.Printf("%d leader: fail to send to %d", rf.me, index)
			cmdQueue.Push(cmd)
			continue
		}
		if changed() {
			continue
		}
		log.Printf("%d[%d] leader: receive %v", rf.me, rf.currentTerm, reply)
		if reply.Term > rf.currentTerm {
			rf.currentTerm = reply.Term
			rf.toFollower()
			rf.mu.Unlock()
			continue
		}
		if !reply.Success {
			rf.nextIndex[index]--
			log.Printf("%d[%d] leader: %d refused", rf.me, rf.currentTerm, index)
			if rf.nextIndex[index] <= 0 {
				log.Fatalf("%d[%d] leader: nextIndex[%d] > 0 check failed", rf.me, rf.currentTerm, index)
			}
			//heartbeat wait next round
			if !isHeartbeat {
				time.Sleep(10 * time.Millisecond)
				cmdQueue.Push(cmd)
			}
		} else {
			log.Printf("%d[%d] leader: %d accepted", rf.me, rf.currentTerm, index)
			if isHeartbeat {
				rf.matchIndex[index] = rf.nextIndex[index] - 1
				rf.mu.Unlock()
				continue
			}
			last := args.PrevLogIndex + len(args.Entries)
			rf.nextIndex[index] = last + 1
			rf.matchIndex[index] = last
			if last > rf.commitIndex {
				count := 0
				for _, matches := range rf.matchIndex {
					if matches >= last {
						count++
					}
				}
				if count*2 > len(rf.peers) {
					log.Printf("%d[%d] leader: update commitIndex to %d", rf.me, rf.currentTerm, last)
					for i := rf.commitIndex + 1; i <= last; i++ {
						rf.applyChan <- ApplyMsg{
							CommandIndex: i,
							CommandValid: true,
							Command:      rf.log[i].Command,
						}
						log.Printf("%d[%d] leader: apply command %d", rf.me, rf.currentTerm, i)
					}
					rf.commitIndex = last
				}
			}
		}
		rf.mu.Unlock()
	}
}

func (rf *Raft) heartbeatTimeout(startTime time.Time) {
	changed := func() bool {
		return rf.killed() || rf.state != LEADER || rf.leaderStartTime != startTime
	}
	for {
		rf.mu.Lock()
		if changed() {
			rf.mu.Unlock()
			return
		}
		log.Printf("%d[%d] leader: send heartbeat", rf.me, rf.currentTerm)
		rf.mu.Unlock()
		for i, q := range rf.cmdQueues {
			if i == rf.me {
				continue
			}
			q.Push(AppendEntriesCommand{
				heartbeat: true,
			})
		}
		time.Sleep(HEARTBEAT_TIMEOUT)
	}
	return
}

func (rf *Raft) leaderFunc(startTime time.Time) {
	rf.mu.Lock()
	if rf.killed() || rf.state != LEADER || rf.leaderStartTime != startTime {
		rf.mu.Unlock()
		return
	}
	rf.mu.Unlock()
	go rf.heartbeatTimeout(startTime)
}

func (rf *Raft) toCandidate() {
	log.Printf("%d[%d]: -> candidate", rf.me, rf.currentTerm)
	rf.state = CANDIDATE
	rf.currentTerm++
	rf.candidateStartTime = time.Now()
	rf.votedFor = rf.me
	rf.persist()
	for _, q := range rf.cmdQueues {
		q.Clear()
	}
	go rf.candidateFunc(rf.candidateStartTime)
}

func (rf *Raft) getVote(i int, args *RequestVoteArgs, validOut chan<- RequestVoteReply, errOut chan<- bool) {
	reply := RequestVoteReply{}
	if ok := rf.sendRequestVote(i, args, &reply); !ok {
		errOut <- true
	} else {
		validOut <- reply
	}
}

func (rf *Raft) election(startTime time.Time) {
	receivedVotes := 0
	allActive := len(rf.peers)
	changed := func() bool {
		return rf.killed() || rf.state != CANDIDATE || rf.candidateStartTime != startTime
	}
	rf.mu.Lock()
	defer rf.mu.Unlock()
	if changed() {
		return
	}
	log.Printf("%d[%d]: into election", rf.me, rf.currentTerm)
	args := RequestVoteArgs{
		CandidateId:  rf.me,
		Term:         rf.currentTerm,
		LastLogIndex: len(rf.log) - 1,
		LastLogTerm:  rf.log[len(rf.log)-1].Term,
	}
	rf.mu.Unlock()
	validOut := make(chan RequestVoteReply)
	errOut := make(chan bool)
	for i := range rf.peers {
		go rf.getVote(i, &args, validOut, errOut)
	}
	for i := range rf.peers {
		select {
		case reply := <-validOut:
			rf.mu.Lock()
			if changed() {
				return
			}
			if reply.Term > rf.currentTerm {
				rf.currentTerm = reply.Term
				rf.toFollower()
				return
			}
			if reply.VoteGranted {
				receivedVotes++
				log.Printf("%d[%d] candidate: receive vote in loop %d", rf.me, rf.currentTerm, i)
				if receivedVotes*2 > allActive {
					log.Printf("%d[%d] candidate: got %d/%d", rf.me, rf.currentTerm, receivedVotes, allActive)
					rf.toLeader()
					return
				}
			}
			rf.mu.Unlock()
		case <-errOut:
			//don't remove offline server
			//allActive--
		}
	}
	rf.mu.Lock()
	if changed() {
		return
	}
	log.Printf("%d[%d] candidate: got %d/%d", rf.me, rf.currentTerm, receivedVotes, allActive)
	//if receivedVotes == allActive: wait until election timeout
	if receivedVotes < allActive {
		rf.toFollower()
	}
	return
}

//func (rf *Raft) candidateFunc(startTime time.Time) {
//rf.election(startTime)
//return
//}

func (rf *Raft) candidateFunc(startTime time.Time) {
	timeout := electionTimeout()
	changed := func() bool {
		return rf.killed() || rf.state != CANDIDATE || rf.candidateStartTime != startTime
	}
	rf.mu.Lock()
	defer rf.mu.Unlock()
	if changed() {
		return
	}
	go rf.election(startTime)
	rf.mu.Unlock()
	time.Sleep(timeout)
	rf.mu.Lock()
	if changed() {
		return
	}
	rf.toCandidate()
	return
}

func (rf *Raft) followerFunc(startTime time.Time) {
	timeout := electionTimeout()
	changed := func() bool {
		return rf.killed() || rf.state != FOLLOWER || rf.followerStartTime != startTime
	}
	rf.mu.Lock()
	defer rf.mu.Unlock()
	if changed() {
		return
	}
	rf.mu.Unlock()
	time.Sleep(timeout)
	rf.mu.Lock()
	if changed() {
		return
	}
	rf.toCandidate()
	return
}

//
// the service or tester wants to create a Raft server. the ports
// of all the Raft servers (including this one) are in peers[]. this
// server's port is peers[me]. all the servers' peers[] arrays
// have the same order. persister is a place for this server to
// save its persistent state, and also initially holds the most
// recent saved state, if any. applyCh is a channel on which the
// tester or service expects Raft to send ApplyMsg messages.
// Make() must return quickly, so it should start goroutines
// for any long-running work.
//
func Make(peers []*labrpc.ClientEnd, me int,
	persister *Persister, applyCh chan ApplyMsg) *Raft {
	rf := &Raft{}
	rf.peers = peers
	rf.persister = persister
	rf.applyChan = applyCh
	rf.me = me
	// initialize from state persisted before a crash
	rf.currentTerm = 1
	rf.votedFor = -1
	// index start from 1, first one is placeholder
	rf.log = make([]LogEntry, 1, 100)
	rf.commitIndex = 0
	rf.lastApplied = 0

	peersNum := len(peers)
	//initialized when selected as leader
	rf.nextIndex = make([]int, peersNum)
	rf.matchIndex = make([]int, peersNum)
	rf.readPersist(persister.ReadRaftState())
	rf.matchIndex[rf.me] = len(rf.log) - 1
	rf.cmdQueues = make([]*Queue, peersNum)
	for i := range rf.cmdQueues {
		rf.cmdQueues[i] = MakeQueue()
		if i != rf.me {
			go rf.appendEntriesFunc(i, rf.cmdQueues[i])
		}
	}

	if rf.votedFor < 0 || rf.votedFor != me {
		rf.toFollower()
	} else {
		rf.toCandidate()
	}
	return rf
}
