package mr

import (
	"log"
	"net"
	"net/http"
	"net/rpc"
	"os"
	"sync"
	"time"
)

type Status int

const (
	INIT Status = iota + 1
	IN_PROGRESS
	COMPLETED
)

type Master struct {
	lock sync.RWMutex

	mapInputs        []string
	mapWorkerTimeout []time.Time
	mapWorkerStatus  []Status

	reduceInputs        []string
	reduceWorkerTimeout []time.Time
	reduceWorkerStatus  []Status
}

func (m *Master) Ping(args *RpcArgs, reply *RpcReply) error {
	status := args.Status
	index := args.Index
	m.lock.Lock()
	defer m.lock.Unlock()
	if status == MAP_PING {
		if index < 0 || index >= len(m.mapWorkerStatus) ||
			m.mapWorkerStatus[index] != IN_PROGRESS {
			return nil
		}
		m.mapWorkerTimeout[index] = time.Now()
	} else if status == REDUCE_PING {
		if index < 0 || index >= len(m.reduceWorkerStatus) ||
			m.reduceWorkerStatus[index] != IN_PROGRESS {
			return nil
		}
		m.reduceWorkerTimeout[index] = time.Now()
	}
	return nil
}

func (m *Master) Register(args *RpcArgs, reply *RpcReply) error {
	m.lock.Lock()
	defer m.lock.Unlock()
	mapDone := true
	for i, _ := range m.mapWorkerStatus {
		if m.mapWorkerStatus[i] == IN_PROGRESS {
			dt := time.Since(m.mapWorkerTimeout[i]).Seconds()
			if dt > 10.0 {
				m.mapWorkerStatus[i] = INIT
			}
			mapDone = false
		}
		if m.mapWorkerStatus[i] == INIT {
			*reply = RpcReply{
				Task:  MAP_TASK,
				Files: []string{m.mapInputs[i]},
				Index: i,
			}
			m.mapWorkerStatus[i] = IN_PROGRESS
			m.mapWorkerTimeout[i] = time.Now()
			return nil
		}
	}
	if !mapDone {
		*reply = RpcReply{
			Task: WAIT,
		}
		return nil
	}
	reduceDone := true
	for i, _ := range m.reduceWorkerStatus {
		if m.reduceWorkerStatus[i] == IN_PROGRESS {
			dt := time.Since(m.reduceWorkerTimeout[i]).Seconds()
			if dt > 10.0 {
				m.reduceWorkerStatus[i] = INIT
			}
			reduceDone = false
		}
		if m.reduceWorkerStatus[i] == INIT {
			*reply = RpcReply{
				Task:    REDUCE_TASK,
				Files:   m.reduceInputs,
				Index:   i,
				NReduce: len(m.reduceWorkerStatus),
			}
			m.reduceWorkerStatus[i] = IN_PROGRESS
			m.reduceWorkerTimeout[i] = time.Now()
			return nil
		}
	}
	if !reduceDone {
		*reply = RpcReply{
			Task: WAIT,
		}
	} else {
		*reply = RpcReply{
			Task: DONE,
		}
	}
	return nil
}

func (m *Master) MapComplete(args *RpcArgs, reply *RpcReply) error {
	index := args.Index
	file := args.File
	m.lock.Lock()
	if index < 0 || index >= len(m.mapInputs) ||
		m.mapWorkerStatus[index] != IN_PROGRESS {
		*reply = RpcReply{
			Task: WAIT,
		}
		m.lock.Unlock()
		return nil
	}
	m.mapWorkerStatus[index] = COMPLETED
	m.reduceInputs[index] = file
	m.lock.Unlock()
	return m.Register(args, reply)
}

func (m *Master) ReduceComplete(args *RpcArgs, reply *RpcReply) error {
	index := args.Index
	m.lock.Lock()
	if index < 0 || index >= len(m.reduceWorkerStatus) ||
		m.reduceWorkerStatus[index] != IN_PROGRESS {
		*reply = RpcReply{
			Task: WAIT,
		}
		m.lock.Unlock()
		return nil
	}
	m.reduceWorkerStatus[index] = COMPLETED
	m.lock.Unlock()
	return m.Register(args, reply)
}

// the RPC argument and reply types are defined in rpc.go.
//
//
// start a thread that listens for RPCs from worker.go
//
func (m *Master) server() {
	rpc.Register(m)
	rpc.HandleHTTP()
	//l, e := net.Listen("tcp", ":1234")
	sockname := masterSock()
	os.Remove(sockname)
	l, e := net.Listen("unix", sockname)
	if e != nil {
		log.Fatal("listen error:", e)
	}
	go http.Serve(l, nil)
}

//
// main/mrmaster.go calls Done() periodically to find out
// if the entire job has finished.
//
func (m *Master) Done() bool {
	m.lock.RLock()
	defer m.lock.RUnlock()
	for _, status := range m.mapWorkerStatus {
		if status != COMPLETED {
			return false
		}
	}
	for _, status := range m.reduceWorkerStatus {
		if status != COMPLETED {
			return false
		}
	}
	return true
}

//
// create a Master.
// main/mrmaster.go calls this function.
// nReduce is the number of reduce tasks to use.
//
func MakeMaster(files []string, nReduce int) *Master {
	nMap := len(files)
	m := Master{
		mapInputs:           files,
		mapWorkerStatus:     make([]Status, nMap),
		mapWorkerTimeout:    make([]time.Time, nMap),
		reduceInputs:        make([]string, nMap),
		reduceWorkerStatus:  make([]Status, nReduce),
		reduceWorkerTimeout: make([]time.Time, nReduce),
	}

	var i int
	for i = 0; i < nMap; i++ {
		m.mapWorkerStatus[i] = INIT
	}

	for i = 0; i < nReduce; i++ {
		m.reduceWorkerStatus[i] = INIT
	}

	m.server()
	return &m
}
