package mr

import (
	"bytes"
	"encoding/json"
	"fmt"
	"hash/fnv"
	"io/ioutil"
	"log"
	"net/rpc"
	"os"
	"sort"
	"time"
)

//
// Map functions return a slice of KeyValue.
//
type KeyValue struct {
	Key   string
	Value string
}

//
// use ihash(key) % NReduce to choose the reduce
// task number for each KeyValue emitted by Map.
//
func ihash(key string) int {
	h := fnv.New32a()
	h.Write([]byte(key))
	return int(h.Sum32() & 0x7fffffff)
}

var (
	WorkerStatus TaskType = WAIT
	ticker       *time.Ticker
	index        int
)

func schedule(interval time.Duration, f func()) {
	ticker = time.NewTicker(interval)
	go func() {
		for range ticker.C {
			f()
		}
	}()
}

func ping() {
	args := RpcArgs{
		Index: index,
	}
	reply := RpcReply{}
	if WorkerStatus == MAP_TASK {
		args.Status = MAP_PING
	} else if WorkerStatus == REDUCE_TASK {
		args.Status = REDUCE_PING
	} else if WorkerStatus == DONE {
		ticker.Stop()
		return
	}
	call("Master.Ping", &args, &reply)
}

func register() (reply RpcReply) {
	args := RpcArgs{}
	call("Master.Register", &args, &reply)
	return
}

func readFile(file string) (data []byte, ok bool) {
	fp, err := os.Open(file)
	ok = false
	if err != nil {
		log.Fatalf("file %s read error: %v", file, err)
	}
	data, err = ioutil.ReadAll(fp)
	if err != nil {
		log.Fatalf("file %s read error: %v", file, err)
	}
	return data, true
}

func doMap(mapf func(string, string) []KeyValue, file string) (data []KeyValue, ok bool) {
	bytes, ok := readFile(file)
	if !ok {
		return
	}
	content := string(bytes[:])
	data = mapf(file, content)
	return data, true
}

func saveMap(keyvals []KeyValue) (path string, ok bool) {
	ok = false
	tmpfile, err := ioutil.TempFile("", "mr-tmp")
	if err != nil {
		log.Fatalf("create temp file error: %v", err)
	}
	enc := json.NewEncoder(tmpfile)
	for _, kv := range keyvals {
		err := enc.Encode(&kv)
		if err != nil {
			log.Fatalf("write json error: %v", err)
		}
	}
	return tmpfile.Name(), true
}

func completeMap(path string, index int) (reply RpcReply) {
	args := RpcArgs{
		Index: index,
		File:  path,
	}
	call("Master.MapComplete", &args, &reply)
	return
}

func loadMap(content []byte) (keyvals []KeyValue) {
	r := bytes.NewReader(content)
	dec := json.NewDecoder(r)
	keyvals = make([]KeyValue, 0, 10)
	for {
		var kv KeyValue
		if err := dec.Decode(&kv); err != nil {
			break
		}
		keyvals = append(keyvals, kv)
	}
	return
}

func doReduce(reducef func(string, []string) string, files []string, index, nReduce int) (result []KeyValue, ok bool) {
	keyvals := make([]KeyValue, 0, 10)
	ok = false
	for _, file := range files {
		content, o := readFile(file)
		if !o {
			return
		}
		data := loadMap(content)
		for _, kv := range data {
			if index == ihash(kv.Key)%nReduce {
				keyvals = append(keyvals, kv)
			}
		}
	}
	sort.Slice(keyvals, func(i, j int) bool {
		return keyvals[i].Key < keyvals[j].Key
	})
	var i = 0
	var j int
	result = make([]KeyValue, 0, 10)
	for i = 0; i < len(keyvals); i = j {
		key := keyvals[i].Key
		vals := []string{keyvals[i].Value}
		for j = i + 1; j < len(keyvals) && keyvals[j].Key == key; j++ {
			vals = append(vals, keyvals[j].Value)
		}
		result = append(result, KeyValue{
			Key:   key,
			Value: reducef(key, vals),
		})
	}
	return result, true
}

func saveReduce(keyvals []KeyValue) (path string, ok bool) {
	ok = false
	dir, err := os.Getwd()
	if err != nil {
		log.Fatalf("get current directory error: %v", err)
	}
	file, err := ioutil.TempFile(dir, "mr-out-")
	if err != nil {
		log.Fatalf("create temp file error: %v", err)
	}
	for _, kv := range keyvals {
		fmt.Fprintf(file, "%v %v\n", kv.Key, kv.Value)
	}
	return file.Name(), true
}

func completeReduce(path string, index int) (reply RpcReply) {
	args := RpcArgs{
		Index: index,
		File:  path,
	}
	call("Master.ReduceComplete", &args, &reply)
	return
}

//
// main/mrworker.go calls this function.
//
func Worker(mapf func(string, string) []KeyValue,
	reducef func(string, []string) string) {
	schedule(time.Second*5, ping)
	reply := RpcReply{
		Task: WAIT,
	}
	for {
		WorkerStatus = reply.Task
		if WorkerStatus == WAIT {
			reply = register()
		} else if WorkerStatus == MAP_TASK {
			file := reply.Files[0]
			index = reply.Index
			keyvals, ok := doMap(mapf, file)
			if !ok {
				break
			}
			path, ok := saveMap(keyvals)
			if !ok {
				break
			}
			WorkerStatus = WAIT
			reply = completeMap(path, index)
		} else if WorkerStatus == REDUCE_TASK {
			files := reply.Files
			index = reply.Index
			nReduce := reply.NReduce
			keyvals, ok := doReduce(reducef, files, index, nReduce)
			if !ok {
				break
			}
			path, ok := saveReduce(keyvals)
			if !ok {
				break
			}
			WorkerStatus = WAIT
			reply = completeReduce(path, index)
		} else if WorkerStatus == DONE {
			break
		}
	}
}

//
// send an RPC request to the master, wait for the response.
// usually returns true.
// returns false if something goes wrong.
//
func call(rpcname string, args interface{}, reply interface{}) bool {
	// c, err := rpc.DialHTTP("tcp", "127.0.0.1"+":1234")
	sockname := masterSock()
	c, err := rpc.DialHTTP("unix", sockname)
	if err != nil {
		log.Fatal("dialing:", err)
	}
	defer c.Close()

	err = c.Call(rpcname, args, reply)
	if err == nil {
		return true
	}

	fmt.Println(err)
	return false
}
